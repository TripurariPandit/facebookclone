import registerCSS from './register.module.css';
import commonCSS from '../../css/login.module.css'
import { Link } from 'react-router-dom';
const Register = () =>{
    return (
        <div className={commonCSS.login}>
            <div className={`${commonCSS.card} ${registerCSS.rightCard}`}>
                <div className={`${commonCSS.left} ${registerCSS.leftBox}`}>
                    <h1>Lama Socail</h1>
                    <p>“Lorem ipsum” dummy textgenerate “Lorem ipsum” text, but now you can do that right in your editor. Just</p>
                    <span>Do you have an account?</span>
                    <Link to='/login'>
                        <button>Login</button>
                    </Link>
                </div>
                <div className={commonCSS.right}>
                    <h1>Register</h1>
                    <form>
                        <input type='text' placeholder='Username' />
                        <input type='email' placeholder='Email' />
                        <input type='password' placeholder='Password' />
                        <input type='text' placeholder='Name' />
                        <button>Register</button> 
                    </form>
                </div>
            </div>
        </div>
    )
}

export default Register;