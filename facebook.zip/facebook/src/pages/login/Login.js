import loginCSS from './login.module.css';
import commonCSS from '../../css/login.module.css'
import { Link } from 'react-router-dom';
import { AuthContext } from '../../contexts/authContext';
import { useContext } from 'react';
const Login = () =>{
    const {login, currentUser} = useContext(AuthContext);
    console.log("currentUser from login", currentUser);
    const handleLogin = ()=>{
        login();
    }
    return (
        <div className={commonCSS.login}>
            <div className={commonCSS.card}>
                <div className={`${commonCSS.left} ${loginCSS.leftBox}`}>
                    <h1>Hello world,</h1>
                    <p>“Lorem ipsum” dummy textgenerate “Lorem ipsum” text, but now you can do that right in your editor. Just</p>
                    <span>Don't you have an account?</span>
                    {/* <button>Register</button> */}
                    <Link to='/register'>
                        <button>Register</button>
                    </Link>
                </div>
                <div className={commonCSS.right}>
                    <h1>Login</h1>
                    <form>
                        <input type='text' placeholder='Username' />
                        <input type='password' placeholder='Password' />
                        <button onClick={handleLogin}>Login</button> 
                    </form>
                </div>
            </div>
        </div>
    )
}

export default Login;