import Posts from '../../components/posts/posts';
import Stories from '../../components/stories/stories';
import AddPost from '../../components/addPosts/AddPost';
import './home.css';

const Home = () =>{
    return(
        <div className='home'>
            <Stories />
            <AddPost />
            <Posts />
        </div>
    )
}

export default Home;