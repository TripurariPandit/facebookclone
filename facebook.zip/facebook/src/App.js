import Layout from "./Layout";
import Home from "./pages/home/Home";
import Login from "./pages/login/Login";
import Profile from "./pages/profile/Profile";
import Register from "./pages/register/Register";
import ProtectedRoute from "./Auth";
import { createBrowserRouter, RouterProvider} from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "./contexts/authContext";
import Friends from './components/friends/Friends';
import Videos from "./components/videos/videos";

function App() {
  // const currentUser = true;
  const {currentUser} = useContext(AuthContext);
  const router = createBrowserRouter([
    {
      path: "/",
      element: <ProtectedRoute currentUser={currentUser}><Layout /></ProtectedRoute>,
      children :[
        {
          path : '/',
          element : <Home /> 
        },
        {
          path : '/profile/:id',
          element : <Profile />
        },
        {
          path : '/friends',
          element : <Friends />
        },
        {
          path : '/videos',
          element : <Videos />
        }
      ]
    },
    {
      path: "/register",
      element: <Register />,
    },
    {
      path: "/login",
      element: <Login />,
    },
  ]);
  return (
    <RouterProvider router={router} />
  );
}

export default App;
