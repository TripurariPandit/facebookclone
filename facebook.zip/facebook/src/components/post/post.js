import postCSS from "./post.module.css";
import FavoriteBorderOutlinedIcon from "@mui/icons-material/FavoriteBorderOutlined";
import FavoriteOutlinedIcon from "@mui/icons-material/FavoriteOutlined";
import TextsmsOutlinedIcon from "@mui/icons-material/TextsmsOutlined";
import ShareOutlinedIcon from "@mui/icons-material/ShareOutlined";
import MoreHorizOutlinedIcon from "@mui/icons-material/MoreHorizOutlined";
import { Link } from "react-router-dom";
import Comments from "../comments/Comments";
import { useState, useContext } from "react";
import { comments } from "../../data/commentsData";
import { AuthContext } from "../../contexts/authContext";
import {likes} from '../../data/likedData';

const Post = ({ post }) => {
  const [commentOpen, setCommentOpen] = useState(false);
  const { currentUser } = useContext(AuthContext);
  const [comment, setComment] = useState("");
  const [liked, setLiked] = useState(false);
  // const liked = true;

  const handleComment = () => {
    console.log("comment is added");
    const commentData = {
      id: comments.length + 1,
      desc: comment,
      name: currentUser.name,
      userId: currentUser.id,
      profilePicture: currentUser.profilePic,
      date: new Date().toISOString(), // Store the current date and time in ISO format
    };
    comments.unshift(commentData);
    setComment("");
  };

  const handleLike = ()=>{
    setLiked(!liked);
    if(!liked){
      const likedData = {
        id: likes.length+1,
        desc: comment,
        name: currentUser.name,
        userId: currentUser.id,
        profilePicture: currentUser.profilePic,
        date: new Date().toISOString(), // Store the current date and time in ISO format
      }
      likes.unshift(likedData);
    } else{
      likes.shift();
    }
    
  }

  return (
    <div className={postCSS.post}>
      <div className={postCSS.container}>
        <div className={postCSS.user}>
          <div className={postCSS.userInfo}>
            <img src={post.profilePic} alt="" />
            <div className={postCSS.details}>
              <Link
                to={`/profile/${post.userId}`}
                style={{ textDecoration: "none", color: "inherit" }}
              >
                <span className={postCSS.name}>{post.name}</span>
              </Link>
              <span className={postCSS.date}>1 min ago</span>
            </div>
          </div>
          <MoreHorizOutlinedIcon />
        </div>
        <div className={postCSS.content}>
          <p>{post.desc}</p>
          <img src={post.img} alt="" />
        </div>
        <div className={postCSS.info}>
          <div className={postCSS.item} onClick={handleLike}>
            {liked ? <FavoriteOutlinedIcon /> :<FavoriteBorderOutlinedIcon />}
            {likes.length} Likes
          </div>
          <div
            className={postCSS.item}
            onClick={() => setCommentOpen(!commentOpen)}
          >
            <TextsmsOutlinedIcon />
            {comments.length} Comments
          </div>
          <div className={postCSS.item}>
            <ShareOutlinedIcon />
            12 Share
          </div>
        </div>
        {commentOpen && <Comments comments={comments} handleComment={handleComment} comment={comment} setComment={setComment} />}
      </div>
    </div>
  );
};

export default Post;
