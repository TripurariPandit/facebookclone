const Videos = ()=>{
    return(
        <div className="Videos">Videos</div>
    )
}

export default Videos;