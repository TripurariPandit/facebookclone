import { useContext, useRef, useState, useEffect } from "react";
import storiesCSS from "./stories.module.css";
import { AuthContext } from "../../contexts/authContext";
import { stories } from "../../data/storiesData";
import ChevronRightOutlinedIcon from "@mui/icons-material/ChevronRightOutlined";
import ChevronLeftOutlinedIcon from "@mui/icons-material/ChevronLeftOutlined";

const Stories = () => {
  const { currentUser } = useContext(AuthContext);
  const storiesContainerRef = useRef(null);
  const [showLeftButton, setShowLeftButton] = useState(false);
  const [showRightButton, setShowRightButton] = useState(true);

  const handleRightButton = () => {
    const storiesContainer = storiesContainerRef.current;
    storiesContainer.scrollBy({
      left: 200, // Scrolls by 200px to the right
      behavior: "smooth",
    });
  };

  const handleLeftButton = () => {
    const storiesContainer = storiesContainerRef.current;
    storiesContainer.scrollBy({
      left: -200, // Scrolls by 200px to the left
      behavior: "smooth",
    });
  };

  useEffect(() => {
    const storiesContainer = storiesContainerRef.current;
    const handleScroll = () => {
      setShowLeftButton(storiesContainer.scrollLeft > 0);
      setShowRightButton(
        storiesContainer.scrollLeft + storiesContainer.clientWidth + 1 <
          storiesContainer.scrollWidth
      );
    };

    storiesContainer.addEventListener("scroll", handleScroll);
    handleScroll();

    return () => {
      storiesContainer.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <div className={storiesCSS.storiesWrapper}>
      <div className={storiesCSS.storiesContainer} ref={storiesContainerRef}>
        <div className={storiesCSS.stories}>
          <div className={storiesCSS.story}>
            <img src={currentUser.profilePic} alt="" />
            <div
              style={{
                backgroundColor: "white",
                color: "black",
                width: "100%",
                position: 'absolute',
                bottom: '0px',
                height: '3rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              {currentUser.name}
            </div>
            <button>+</button>
          </div>
          {stories.map((story) => (
            <div className={storiesCSS.story} key={story.id}>
              <img src={story.img} alt="" />
              <span>{story.name}</span>
              <img
                src={currentUser.profilePic}
                className={storiesCSS.userImg}
                alt=""
              />
            </div>
          ))}
        </div>
      </div>
      {showLeftButton && (
        <div className={storiesCSS.leftButton} onClick={handleLeftButton}>
          <ChevronLeftOutlinedIcon />
        </div>
      )}
      {showRightButton && (
        <div className={storiesCSS.rightButton} onClick={handleRightButton}>
          <ChevronRightOutlinedIcon />
        </div>
      )}
    </div>
  );
};

export default Stories;
