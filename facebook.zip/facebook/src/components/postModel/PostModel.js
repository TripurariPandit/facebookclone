import React from "react";
import postModelCSS from "./postModel.module.css";
import CloseOutlinedIcon from "@mui/icons-material/CloseOutlined";

const PostModel = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className={postModelCSS.modalOverlay} onClick={onClose}>
      <div
        className={postModelCSS.modalContent}
        onClick={(e) => e.stopPropagation()}
      >
        <div className={postModelCSS.modalHeader}>
          <h3 className={postModelCSS.modalTitle}>Create post</h3>
          <CloseOutlinedIcon
            className={postModelCSS.closeButton}
            onClick={onClose}
          />
        </div>
        <hr></hr>
      </div>
    </div>
  );
};

export default PostModel;

