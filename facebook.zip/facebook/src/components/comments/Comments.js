import { useContext } from 'react';
import commentsCSS from './comments.module.css';
import { AuthContext } from '../../contexts/authContext';

const Comments = ({comments, handleComment, comment, setComment}) => {
    const { currentUser } = useContext(AuthContext);
    const handleChange = (event) => {
        const value = event.target.value;
        setComment(value);
    }

    const addComent = ()=>{
        handleComment();
    }

    const getTimeDifference = (date) => {
        const now = new Date();
        const commentDate = new Date(date);
        const diffInSeconds = Math.floor((now - commentDate) / 1000);

        if (diffInSeconds < 60) {
            return 'just now';
        } else if (diffInSeconds < 3600) {
            const minutes = Math.floor(diffInSeconds / 60);
            return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        } else if (diffInSeconds < 86400) {
            const hours = Math.floor(diffInSeconds / 3600);
            return `${hours} hour${hours > 1 ? 's' : ''} ago`;
        } else {
            const days = Math.floor(diffInSeconds / 86400);
            return `${days} day${days > 1 ? 's' : ''} ago`;
        }
    }

    return (
        <div className={commentsCSS.comments}>
            <div className={commentsCSS.write}>
                <img src={currentUser.profilePic} alt='' />
                <input type='text' placeholder='write a comment' value={comment} onChange={handleChange} />
                <button onClick={addComent}>Send</button>
            </div>
            {comments.map((comment) => (
                <div className={commentsCSS.comment} key={comment.id}>
                    <img src={comment.profilePicture} alt='' />
                    <div className={commentsCSS.info}>
                        <span>{comment.name}</span>
                        <p>{comment.desc}</p>
                    </div>
                    <span className={commentsCSS.date}>
                        {getTimeDifference(comment.date)}
                    </span>
                </div>
            ))}
        </div>
    )
}

export default Comments;
