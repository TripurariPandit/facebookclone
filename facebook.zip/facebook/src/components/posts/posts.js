import postsCSS from './posts.module.css';
import Post from '../post/post';
import { posts } from '../../data/postsData';
const Posts = () =>{
    return(
        <div className={postsCSS.posts}>
            {posts.map((post) =>(
                <Post post ={post} key={post.id}/>
            ))}
        </div>
    )
}

export default Posts;