import rightBarCSS from "./rightBar.module.css";
import {
  suggestions,
  latestActivities,
  onlineFriends,
} from "../../data/rightBarData";

import {followings} from '../../data/followingData';
import { useState } from "react";

const RightBar = () => {
  const [suggestion, setSuggestion] = useState(suggestions);
  const [following, setFollowing] = useState(followings);
  
  const handleFollow = (id) => {
    const updatedSuggestions = suggestion.filter((suggestion) => suggestion.id !== id);
 
    const followed = suggestion.find((suggestion) => suggestion.id === id);

    setSuggestion(updatedSuggestions);

    if (followed) {
      setFollowing((prevFollowing) => [followed, ...prevFollowing]);
    }
  }

  const handleDismiss = (id)=>{
    const updatedSuggestions = suggestion.filter((suggestion) => suggestion.id !== id);
    setSuggestion(updatedSuggestions);
  }

  return (
    <div className={rightBarCSS.rightBar}>
      <div className={rightBarCSS.container}>
        <div className={rightBarCSS.item}>
          <span>Suggestions For You</span>
          {suggestion.map((suggestion) => (
            <div className={rightBarCSS.user} key={suggestion.id}>
              <div className={rightBarCSS.userInfo}>
                <img src={suggestion.src} alt="" />
                <span>{suggestion.name}</span>
              </div>
              <div className={rightBarCSS.buttons}>
                <button onClick={() =>handleFollow(suggestion.id)}>follow</button>
                <button onClick={()=> handleDismiss(suggestion.id)}>dismiss</button>
              </div>
            </div>
          ))}
        </div>

        <div className={rightBarCSS.item}>
          <span>Latest Activities</span>
          {latestActivities.map((latestActivity) => (
            <div className={rightBarCSS.user} key={latestActivity.id}>
              <div className={rightBarCSS.userInfo}>
                <div>
                  <img src={latestActivity.src} alt="" />
                </div>
                <p>
                  <span>{latestActivity.name} </span>
                  {latestActivity.activity}
                </p>
              </div>
              <span>{latestActivity.timeStamp}</span>
            </div>
          ))}
        </div>

        <div className={rightBarCSS.item}>
          <span>Online Friends</span>
          {onlineFriends.map((onlineFriend) => (
            <div className={rightBarCSS.user} key={onlineFriend.id}>
              <div className={rightBarCSS.userInfo}>
                <img src={onlineFriend.src} alt="" />
                <div className={rightBarCSS.online}></div>
                <span>{onlineFriend.name} </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RightBar;
