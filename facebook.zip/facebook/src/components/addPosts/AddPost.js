import React, { useState, useContext } from 'react';
import { Link } from 'react-router-dom';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import CollectionsIcon from '@mui/icons-material/Collections';
import EmojiEmotionsOutlinedIcon from '@mui/icons-material/EmojiEmotionsOutlined';
import { AuthContext } from '../../contexts/authContext';
import addPostCSS from './addPost.module.css';
import PostModel from '../postModel/PostModel';
import FillingModel from '../fillingModel/FillingModel';

const AddPost = () => {
    const { currentUser } = useContext(AuthContext);
    const [isPostModalOpen, setPostModalOpen] = useState(false);
    const [isFillingModelOpen, setFillingModelOpen] = useState(false);

    const openAddModal = () =>{
        console.log("add post model clicked")
        setPostModalOpen(true);
    } 

    const closeModal = () =>{
        setPostModalOpen(false);
    } 

    const openFillingModel = ()=>{
        setFillingModelOpen(true);
    }

    const closeFillingModel = ()=>{
        setFillingModelOpen(false);
    }

    return (
        <div className={addPostCSS.addPostContainer}>
            <div className={addPostCSS.addPost}>
                <Link to='/profile/:id'>
                    <img src={currentUser.profilePic} alt="" />
                </Link>
                <button onClick={openAddModal}>what's on your mind, {currentUser.name} ?</button>
            </div>
            <hr></hr>
            <div className={addPostCSS.iconsContainer}>
                <div className={addPostCSS.icons}>
                    <VideoCallIcon style={{ color: 'red' }} />
                    <span>Live</span>
                </div>
                <div className={addPostCSS.icons} onClick={openAddModal}>
                    <CollectionsIcon style={{ color: 'rgb(0, 128, 66)' }} />
                    <span>Photo/Video</span>
                </div>
                <div className={addPostCSS.icons} onClick={openFillingModel}>
                    <EmojiEmotionsOutlinedIcon style={{ color: 'rgb(255, 157, 0)' }} />
                    <span>Fillings</span>
                </div>
            </div>
            <PostModel isOpen={isPostModalOpen} onClose={closeModal} />
            <FillingModel isOpen={isFillingModelOpen} onClose={closeFillingModel}/>
        </div>
    );
};

export default AddPost;
