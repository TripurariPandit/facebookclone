import friendCSS from './friends.module.css';
function Friends(){
    return(
        <div className={friendCSS.friends}>
            Friends list
        </div>
    )
}

export default Friends;