import leftBarCss from "./leftBar.module.css";
import { userData, shortcuts, others } from "../../data/leftBarData";
import { AuthContext } from "../../contexts/authContext";
import { useContext } from "react";
import { Link } from "react-router-dom";

const LeftBar = () => {
  const { currentUser } = useContext(AuthContext);
  
  const getPath = (user)=>{
    let linkTo;
    switch (user.content) {
      case 'Friends':
        linkTo = '/friends';
        break;
      case 'Watch':
        linkTo = '/videos';
        break;
      case 'Messages':
        linkTo = '/messages';
        break;
      case 'Settings':
        linkTo = '/settings';
        break;
      default:
        linkTo = '/';
        break;
    }
    return linkTo;
  }
  return (
    <div className={leftBarCss.leftBar}>
      <div className={leftBarCss.container}>
        <div className={leftBarCss.menu}>
          <div className={leftBarCss.user}>
            <img src={currentUser.profilePic} alt="user" />
            <span>{currentUser.name}</span>
          </div>
          {userData.map((user) => (
            <div className={leftBarCss.item} key={user.id}>
                <Link
                  to={getPath(user)}
                  style={{
                    textDecoration: "none",
                    color: "inherit",
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                  }}
                 >
                  <img src={user.src} alt="" />
                  <span>{user.content}</span>
                </Link>
            </div>
          ))}
        </div>
        <hr />
        <div className={leftBarCss.menu}>
          <span>Your Shortcuts</span>
          {shortcuts.map((shortcut) => (
            <div className={leftBarCss.item} key={shortcut.id}>
              <img src={shortcut.src} alt="" />
              <span>{shortcut.content}</span>
            </div>
          ))}
        </div>
        <hr />
        <div className={leftBarCss.menu}>
          <span>Others</span>
          {others.map((other) => (
            <div className={leftBarCss.item} key={other.id}>
              <img src={other.src} alt="" />
              <span>{other.content}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LeftBar;
