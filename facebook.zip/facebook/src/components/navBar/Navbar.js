import navBarCSS from "./navBar.module.css";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
import GridViewOutlinedIcon from "@mui/icons-material/GridViewOutlined";
import { Link } from "react-router-dom";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import { useContext, useState } from "react";
import { AuthContext } from "../../contexts/authContext";

const NavBar = () => {
  const { currentUser } = useContext(AuthContext);
  const [isChatOpen, setChatOpen] = useState(false);
  const handleChange = () => {};
  const handleClick = ()=>{

  }
  return (
    <div className={navBarCSS.navbar}>
      <div className={navBarCSS.left}>
        <Link to="/" style={{ textDecoration: "none" }}>
          <span>lamasocial</span>
        </Link>
        <Link to="/" style={{ textDecoration: "none", color: "inherit" }}>
          <HomeOutlinedIcon />
        </Link>
        <DarkModeOutlinedIcon />
        <div className={navBarCSS.search}>
          <SearchOutlinedIcon />
          <input type="text" placeholder="Seach..." onChange={handleChange} />
        </div>
      </div>
      <div className={navBarCSS.right}>
        <div className={navBarCSS.icons}>
          <GridViewOutlinedIcon style={{ fontSize: "1rem" }} />
          <span className={navBarCSS.tooltip}>Menu</span>
        </div>
        <div className={navBarCSS.icons}>
          <i
            className="fa-brands fa-facebook-messenger"
            style={{ fontSize: "1rem" }}
          ></i>
          <span className={navBarCSS.tooltip}>Chat</span>
          <span className={navBarCSS.chatCount}>1</span>
        </div>
        <div className={navBarCSS.icons} onClick={handleClick}>
          <NotificationsOutlinedIcon style={{ fontSize: "1rem" }} />
          <span className={navBarCSS.tooltip}>Notifications</span>
          <span className={navBarCSS.chatCount}>1</span>
        </div>
        <div className={navBarCSS.user}>
          <img src={currentUser.profilePic} alt="user" />
        </div>
      </div>
    </div>
  );
};

export default NavBar;
