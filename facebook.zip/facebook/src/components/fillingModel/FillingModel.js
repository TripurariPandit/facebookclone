import React from "react";
import fillingModelCSS from "./fillingModel.module.css";
import WestOutlinedIcon from "@mui/icons-material/WestOutlined";
import { Link } from "react-router-dom";

const FillingModel = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className={fillingModelCSS.modalOverlay} onClick={onClose}>
      <div
        className={fillingModelCSS.modalContent}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "100px" }}>
          <Link to='' style={{textDecoration: 'none', color: 'inherit'}}>
            <WestOutlinedIcon
              className={fillingModelCSS.closeButton}
            />
          </Link>
          <h3>How are you felling?</h3>
        </div>
        <hr></hr>
      </div>
    </div>
  );
};

export default FillingModel;
