import { Outlet } from "react-router-dom";
import LeftBar from "./components/leftBar/LeftBar";
import NavBar from "./components/navBar/Navbar"
import RightBar from "./components/rightBar/RightBar";
import style from './style.module.css';

const Layout = () =>{
    return(
        <div className={style.darkTheme}>
            <NavBar />
            <div style={{display: "flex"}}>
                <LeftBar />
                <div style={{flex:6}}>
                    <Outlet />
                </div>
                <RightBar />
            </div>
        </div>
    )
}

export default Layout;