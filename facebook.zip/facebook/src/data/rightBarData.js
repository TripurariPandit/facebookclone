const suggestions = [
  {
    id: 1,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 2,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 3,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 4,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
];

const latestActivities = [
  {
    id: 1,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
    activity: "changed their cover picture",
    timeStamp: "1 min ago",
  },
  {
    id: 2,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
    activity: "changed their cover picture",
    timeStamp: "1 min ago",
  },
  {
    id: 3,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
    activity: "changed their cover picture",
    timeStamp: "1 min ago",
  },
  {
    id: 4,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
    activity: "changed their cover picture",
    timeStamp: "1 min ago",
  },
];

const onlineFriends = [
  {
    id: 1,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 2,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 3,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 4,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 5,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 6,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 7,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 8,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 9,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 10,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 11,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 12,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 13,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
  {
    id: 14,
    src: "https://images.pexels.com/photos/4881619/pexels-photo-4881619.jpeg?auto=compress&cs=tinysrgb&w=1600",
    name: "Jane Deo",
  },
];

export { suggestions, latestActivities, onlineFriends };
