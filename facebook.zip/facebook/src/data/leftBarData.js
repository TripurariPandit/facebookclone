import friends from "../assets/1.png";
import groups from "../assets/2.png";
import market from "../assets/3.png";
import watch from "../assets/4.png";
import memories from "../assets/5.png";
import events from "../assets/6.png";
import gaming from "../assets/7.png";
import gallery from "../assets/8.png";
import videos from "../assets/9.png";
import messages from "../assets/10.png";
import tutorials from "../assets/11.png";
import courses from "../assets/12.png";
import fund from "../assets/13.png";

const userData = [
    {
        id: 1,
        src: friends,
        content : 'Friends'
    },
    {
        id: 2,
        src: groups,
        content : 'Groups'
    },
    {
        id: 3,
        src: market,
        content : 'Market'
    },
    {
        id: 4,
        src: watch,
        content : 'Watch'
    },
    {
        id: 5,
        src: memories,
        content : 'Memories'
    },
]

const shortcuts = [
    {
        id: 1,
        src: events,
        content: 'Event'
    },
    {
        id: 2,
        src: gaming,
        content: 'Gaming'
    },
    {
        id: 3,
        src: gallery,
        content: 'Gallery'
    },
    {
        id: 4,
        src: videos,
        content: 'Videos'
    },
    {
        id: 5,
        src: messages,
        content: 'Messages'
    },
]

const others =[
    {
        id: 1,
        src: tutorials,
        content: 'Tutorials'
    },
    {
        id: 2,
        src: courses,
        content: 'Courses'
    },
    {
        id: 3,
        src: fund,
        content: 'Fund'
    },
]

export {userData, shortcuts, others};