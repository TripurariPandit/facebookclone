const followings = [
    {
        id: 1,
        name: '',
        profilePic: ''
    },
    {
        id: 2,
        name: '',
        profilePic: ''
    },
    {
        id: 3,
        name: '',
        profilePic: ''
    },
];

export {followings};